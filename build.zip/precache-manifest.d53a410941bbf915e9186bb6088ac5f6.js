self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b44b0202878d0642c9e83d1e253f72d5",
    "url": "/index.html"
  },
  {
    "revision": "348fc8965b725b6aaea4",
    "url": "/static/css/main.7da98dc4.chunk.css"
  },
  {
    "revision": "a41a8d3371c6591fb88d",
    "url": "/static/js/2.b2692020.chunk.js"
  },
  {
    "revision": "fdc84dfb581e6fb8755dd1b2b01a50e1",
    "url": "/static/js/2.b2692020.chunk.js.LICENSE.txt"
  },
  {
    "revision": "348fc8965b725b6aaea4",
    "url": "/static/js/main.7aa8eafe.chunk.js"
  },
  {
    "revision": "002ea5d9f8bfec91122a",
    "url": "/static/js/runtime-main.5f0d9bc7.js"
  },
  {
    "revision": "e5e6e235f490032482ea04e65f989b18",
    "url": "/static/media/buhuhuwhite.e5e6e235.png"
  },
  {
    "revision": "0855622a64f97bf41f8086ca2883d0e6",
    "url": "/static/media/gost.0855622a.svg"
  },
  {
    "revision": "7385661f68809c8ea32c9ba0cdc31bdf",
    "url": "/static/media/ios.7385661f.png"
  }
]);